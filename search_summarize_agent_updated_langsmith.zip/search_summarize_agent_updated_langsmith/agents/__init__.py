### agents/__init__.py

"""
Agents module initialization for standalone Search & Summarize Agent
"""

from .search_summarize_agent import SearchAndSummarizeAgent

__all__ = [
    'SearchAndSummarizeAgent'
]