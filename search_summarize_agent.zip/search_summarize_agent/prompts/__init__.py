### prompts/__init__.py

"""
Prompts module initialization for standalone Search & Summarize Agent
"""

from .search_summarize_prompts import TOOL_SELECTION_PROMPT, SUMMARIZATION_PROMPT

__all__ = [
    'TOOL_SELECTION_PROMPT',
    'SUMMARIZATION_PROMPT'
]
