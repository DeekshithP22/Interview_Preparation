### utils/state_models.py

"""
State Models for Standalone Search & Summarize Agent
"""

from typing import Dict, List, Any, Optional, TypedDict, Annotated
from enum import Enum
import operator
from langchain_core.messages import BaseMessage


class SearchWorkflowStatus(Enum):
    INITIATED = "initiated"
    TOOLS_SELECTED = "tools_selected"
    SEARCH_COMPLETED = "search_completed"
    SUMMARIZATION_COMPLETED = "summarization_completed"
    ERROR = "error"


class SearchAgentState(TypedDict):
    # Input - Simple search input and VR data
    search_input: Dict[str, Any]  # Simple search parameters from supervisor
    vr_data: Optional[Dict[str, Any]]  # Original VR data for comparison
    
    # Search Agent state
    selected_tools: List[str]
    execution_order: List[str]
    search_results: Annotated[List[Dict[str, Any]], operator.add]
    intelligent_summary: Optional[Dict[str, Any]]
    search_confidence: float
    
    # Workflow management
    workflow_status: SearchWorkflowStatus
    error_context: Optional[Dict[str, Any]]
    
    # Communication
    messages: Annotated[List[BaseMessage], operator.add]
