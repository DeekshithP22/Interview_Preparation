### main.py

"""
Standalone Search & Summarize Agent - Main Entry Point
"""

import asyncio
import logging
from langgraph.graph import StateGraph, END, START
from langchain_core.messages import AIMessage
from utils.state_models import SearchAgentState, SearchWorkflowStatus
from agents.search_summarize_agent import SearchAndSummarizeAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def handle_error(state: SearchAgentState) -> SearchAgentState:
    """Global error handler for search workflow"""
    error_context = state.get("error_context", {})
    error_msg = f"Error in {error_context.get('stage', 'unknown')}: {error_context.get('error', 'Unknown error')}"
    
    logger.error(error_msg)
    state["messages"].append(AIMessage(content=error_msg))
    state["workflow_status"] = SearchWorkflowStatus.ERROR
    
    return state


def create_search_summarize_workflow():
    """
    Create standalone LangGraph workflow for Search & Summarize Agent
    """
    
    # Initialize the search agent
    search_summarize = SearchAndSummarizeAgent()
    
    # Define workflow graph
    workflow = StateGraph(SearchAgentState)
    
    # Search & Summarize Agent nodes
    workflow.add_node("select_tools", search_summarize.select_search_tools)
    workflow.add_node("execute_search", search_summarize.execute_search_tools)
    workflow.add_node("summarize_results", search_summarize.intelligent_summarization)
    
    # Error handler node
    workflow.add_node("handle_error", handle_error)
    
    # WORKFLOW EDGES
    workflow.add_edge(START, "select_tools")
    workflow.add_edge("select_tools", "execute_search")
    workflow.add_edge("execute_search", "summarize_results")
    
    # Final decision - complete or handle error
    workflow.add_conditional_edges(
        "summarize_results",
        lambda x: "complete" if x.get("workflow_status") == SearchWorkflowStatus.SUMMARIZATION_COMPLETED else "handle_error",
        {
            "complete": END,
            "handle_error": "handle_error"
        }
    )
    
    # Error handler to END
    workflow.add_edge("handle_error", END)
    
    # Compile workflow
    return workflow.compile()


async def process_search_request(search_input: dict, vr_data: dict = None) -> dict:
    """
    Process a search request through the standalone workflow
    
    Args:
        search_input: Simple search input dict
        vr_data: Original VR data for comparison
        
    Returns:
        Workflow result including intelligent summary
    """
    logger.info(f"Processing search request for: {search_input.get('firstName', '')} {search_input.get('lastName', '')}")
    
    # Create workflow
    app = create_search_summarize_workflow()

    # Initial state
    initial_state = SearchAgentState(
        search_input=search_input,
        vr_data=vr_data,
        selected_tools=[],
        execution_order=[],
        search_results=[],
        intelligent_summary=None,
        search_confidence=0.0,
        workflow_status=SearchWorkflowStatus.INITIATED,
        error_context=None,
        messages=[]
    )
    
    # Execute workflow
    result = await app.ainvoke(initial_state)
    
    logger.info(f"Search workflow completed - Status: {result['workflow_status'].value}")
    
    return result


# For testing standalone agent
async def main():
    """
    Example usage - process search input
    """
    # Simple search input (what supervisor agent would pass)
    search_input_sample = {
        "verification_needed": True,
        "geographic_region": "IT",
        "firstName": "Marcello",
        "lastName": "Marchetti",
        "workplaceName": "Fondazione IRCCS Istituto Neurologico Carlo Besta",
        "address": "Milano",
        "specialtyCode": "18"
    }
    
    # VR data (original validation request)
    vr_data_sample = {
        "validation.refAreaEid": "RAR_ITALY",
        "validation.id": 1019001316927770,
        "validation.customerId": 7433,
        "validation.externalId": "47064408",
        "validation.customerRequestEid": "1-ALD8GCL/1-ALD8GE2",
        "validation.vrTypeCode": "VMR",
        "validation.countryCode": "IT",
        "validation.entityTypeIco": "ENT_ACTIVITY",
        "validation.integrationDate": "2025-06-02T07:16:43Z",
        "validation.requestDate": "2025-06-02T07:16:43Z",
        "validation.requestComment": "Automatically Created",
        "validation.statusIco": "VAS_NOT_PROCESSED",
        "validation.isForced": False,
        "validation.businessStatusCode": "C",
        "validation.statusDate": "2025-06-02T07:16:43Z",
        "validation.requesterId": "97433",
        "validation.requesterLastName": "fathimathsireen.ma@iqvia.com",
        "validation.slaRemainingNumDays": 4,
        "validation.slaDate": "2025-06-12",
        "validation.slaNumDays": 8,
        "individual.firstName": "Marcello",
        "individual.lastName": "Marchetti",
        "workplace.usualName": "Fondazione IRCCS Istituto Neurologico Carlo Besta",
        "address.country": "IT",
        "address.city": "Milano",
        "address.postalCity": "Milano",
        "matchingCandidatesKeys": [
            "WIT10546253201",
            "WIT10546253202"
        ]
    }
    
    result = await process_search_request(search_input_sample, vr_data_sample)
    
    print("\n=== SEARCH WORKFLOW RESULTS ===")
    print(f"Workflow Status: {result['workflow_status'].value}")
    print(f"Selected Tools: {result.get('selected_tools', [])}")
    print(f"Search Confidence: {result.get('search_confidence', 0.0)}")
    
    if result.get("intelligent_summary"):
        summary = result["intelligent_summary"]
        print(f"\nIntelligent Summary:")
        print(f"  Primary Finding: {summary.get('overall_assessment', {}).get('primary_finding', 'N/A')}")
        print(f"  Confidence Level: {summary.get('overall_assessment', {}).get('confidence_level', 0.0)}")
        print(f"  Manual Review: {summary.get('overall_assessment', {}).get('manual_review_recommended', False)}")


if __name__ == "__main__":
    asyncio.run(main())
