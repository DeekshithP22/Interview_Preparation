### config.py

"""
Configuration settings for standalone Search & Summarize Agent
"""
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Azure OpenAI
    AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
    AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
    AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4")
    
    # Workflow settings
    MAX_RETRIES = 3
    TIMEOUT_SECONDS = 300
    
    # Tool settings
    TOOL_TIMEOUT = 60  # seconds per tool
    MIN_CONFIDENCE_THRESHOLD = 0.70
    TARGET_CONFIDENCE_THRESHOLD = 0.85
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")