### batch_search_processor.py

"""
Batch processor for multiple search requests with VR data
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import List, Dict, Any
from main import process_search_request

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def process_search_batch(search_requests_with_vr: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Process a batch of search requests with VR data
    
    Args:
        search_requests_with_vr: List of dictionaries containing both search input and VR data
    
    Returns:
        List of search results
    """
    batch_id = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    try:
        logger.info(f"Processing batch of {len(search_requests_with_vr)} search requests with VR data")
        
        results = []
        for idx, request_data in enumerate(search_requests_with_vr):
            request_id = request_data.get("request_id", f"request_{idx}")
            search_input = request_data.get("search_input", {})
            vr_data = request_data.get("vr_data", {})
            
            logger.info(f"Processing search request {idx + 1}/{len(search_requests_with_vr)} - ID: {request_id}")
            
            try:
                result = await process_search_request(search_input, vr_data)
                results.append({
                    "request_id": request_id,
                    "status": "success",
                    "search_result": result
                })
                logger.info(f"Search request {request_id} completed successfully")
                
            except Exception as e:
                logger.error(f"Error processing search request {request_id}: {str(e)}")
                results.append({
                    "request_id": request_id,
                    "status": "error",
                    "error": str(e),
                    "vr_id": vr_data.get("validation.id", "unknown")
                })
        
        # Save batch results
        output_filename = f"search_batch_results_{batch_id}.json"
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        success_count = len([r for r in results if r["status"] == "success"])
        error_count = len([r for r in results if r["status"] == "error"])
        
        logger.info(f"Batch processing complete. Results saved to: {output_filename}")
        logger.info(f"Summary: {success_count} successful, {error_count} failed")
        
        return results
        
    except Exception as e:
        logger.error(f"Batch processing error: {str(e)}")
        raise

if __name__ == "__main__":
    # Example batch of search requests with VR data
    sample_batch = [
        {
            "request_id": "IT_001",
            "search_input": {
                "verification_needed": True,
                "geographic_region": "IT",
                "firstName": "Marcello",
                "lastName": "Marchetti",
                "workplaceName": "Fondazione IRCCS Istituto Neurologico Carlo Besta",
                "address": "Milano",
                "specialtyCode": "18"
            },
            "vr_data": {
                "validation.refAreaEid": "RAR_ITALY",
                "validation.id": 1019001316927770,
                "validation.customerId": 7433,
                "validation.externalId": "47064408",
                "validation.entityTypeIco": "ENT_ACTIVITY",
                "validation.countryCode": "IT",
                "individual.firstName": "Marcello",
                "individual.lastName": "Marchetti",
                "workplace.usualName": "Fondazione IRCCS Istituto Neurologico Carlo Besta",
                "address.country": "IT",
                "address.city": "Milano",
                "address.postalCity": "Milano"
            }
        },
        {
            "request_id": "FR_001", 
            "search_input": {
                "verification_needed": True,
                "geographic_region": "FR",
                "firstName": "Marie",
                "lastName": "Dubois",
                "workplaceName": "Hopital Saint-Antoine",
                "address": "Paris",
                "specialtyCode": "22"
            },
            "vr_data": {
                "validation.refAreaEid": "RAR_FRANCE",
                "validation.id": 1019001316927771,
                "validation.customerId": 7434,
                "validation.externalId": "47064409",
                "validation.entityTypeIco": "ENT_ACTIVITY",
                "validation.countryCode": "FR",
                "individual.firstName": "Marie",
                "individual.lastName": "Dubois",
                "workplace.usualName": "Hopital Saint-Antoine",
                "address.country": "FR",
                "address.city": "Paris",
                "address.postalCity": "Paris"
            }
        }
    ]
    
    asyncio.run(process_search_batch(sample_batch))