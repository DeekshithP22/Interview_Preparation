### prompts/search_summarize_prompts.py

"""
Prompt Templates for Standalone Search & Summarize Agent
"""

from langchain_core.prompts import ChatPromptTemplate

TOOL_SELECTION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are selecting search tools for healthcare professional verification.

Available Tools:
1. italy_trusted - Italian medical registries (FNOMCEO, FNOPI, etc.) - Reliability: 0.95
2. france_trusted - French medical directories (Annuaire Santé, etc.) - Reliability: 0.95
3. hospital_sources - Hospital websites and staff directories - Reliability: 0.80
4. linkedin_professional - Professional networking platforms - Reliability: 0.70
5. untrusted_web_search - General web search engines - Reliability: 0.50

Tool Selection Strategy:
- Geographic Priority: Match tools to individual's country/region
- Confidence Requirements: Higher confidence needs → prioritize trusted sources
- Verification Scope: Multiple objectives → include multiple tool types
- Efficiency: Start with most reliable sources, add others if needed

Execution Order Priority:
1. Country-specific trusted medical registries
2. Hospital/institutional sources
3. Professional networks
4. General web search (only if necessary)

Respond with JSON:
{{
    "selected_tools": ["tool1", "tool2", "tool3"],
    "execution_order": ["tool1", "tool2", "tool3"],
    "tool_rationale": {{
        "tool1": "Primary tool rationale",
        "tool2": "Secondary tool rationale"
    }}
}}"""),
    ("human", """
Search Input: {search_input}

Select appropriate tools and execution strategy.
""")
])

SUMMARIZATION_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are summarizing search results for healthcare professional verification.

You have access to:
1. Original VR validation data
2. Simple search input from supervisor
3. External search results from multiple sources

Your tasks:
1. Compare VR data against search findings
2. Identify any discrepancies or confirmations
3. Assess reliability of verification
4. Provide actionable recommendations

Respond with JSON:
{{
    "verification_results": {{
        "primary_objectives_achieved": ["list of verified objectives"],
        "vr_vs_search_comparison": {{
            "matches": ["fields that match between VR and search"],
            "discrepancies": ["fields that don't match"],
            "missing_data": ["fields not found in search"]
        }},
        "employment_status": {{"status": "confirmed/uncertain", "details": "..."}},
        "professional_credentials": {{"status": "confirmed/uncertain", "details": "..."}}
    }},
    "overall_assessment": {{
        "primary_finding": "Main conclusion about verification",
        "confidence_level": 0.XX,
        "manual_review_recommended": true/false,
        "manual_review_reasons": ["reasons if recommended"]
    }},
    "summary_narrative": "Human-readable summary for DBO review"
}}"""),
    ("human", """
Search Input: {search_input}
Search Results: {search_results}
VR Data: {vr_data}

Create intelligent summary comparing VR data with search findings.
""")
])
