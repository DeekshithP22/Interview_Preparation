### utils/helpers.py

"""
Helper utilities for standalone Search & Summarize Agent
"""
import json
import re
from typing import Dict, Any

def safe_json_parse(content: str) -> Dict[str, Any]:
    """
    Safely parse JSON from LLM response
    Handles markdown code blocks and malformed JSON
    """
    try:
        # First try direct parsing
        return json.loads(content)
    except json.JSONDecodeError:
        # Try to extract JSON from markdown code blocks
        json_match = re.search(r'```json\s*(.*?)\s*```', content, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except:
                pass
        
        # Try to find JSON-like content
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(0))
            except:
                pass
    
    # Return empty dict if all parsing fails
    return {}
