### test_search_agent.py

"""
Test script for standalone Search & Summarize Agent
"""

import asyncio
from main import process_search_request

async def test_basic_search():
    """Test basic search functionality with VR data"""
    
    # Test Case 1: Italian Medical Professional
    italian_search_input = {
        "verification_needed": True,
        "geographic_region": "IT",
        "firstName": "Marcello",
        "lastName": "Marchetti",
        "workplaceName": "Fondazione IRCCS Istituto Neurologico Carlo Besta",
        "address": "Milano",
        "specialtyCode": "18"
    }
    
    # VR data for Italian case
    italian_vr_data = {
        "validation.refAreaEid": "RAR_ITALY",
        "validation.id": 1019001316927770,
        "validation.customerId": 7433,
        "validation.externalId": "47064408",
        "validation.customerRequestEid": "1-ALD8GCL/1-ALD8GE2",
        "validation.vrTypeCode": "VMR",
        "validation.countryCode": "IT",
        "validation.entityTypeIco": "ENT_ACTIVITY",
        "individual.firstName": "Marcello",
        "individual.lastName": "Marchetti",
        "workplace.usualName": "Fondazione IRCCS Istituto Neurologico Carlo Besta",
        "address.country": "IT",
        "address.city": "Milano",
        "address.postalCity": "Milano",
        "matchingCandidatesKeys": [
            "WIT10546253201",
            "WIT10546253202"
        ]
    }
    
    print("=== Testing Italian Medical Professional ===")
    result = await process_search_request(italian_search_input, italian_vr_data)
    print(f"Status: {result['workflow_status'].value}")
    print(f"Tools: {result.get('selected_tools', [])}")
    print(f"Confidence: {result.get('search_confidence', 0.0)}")
    print()

async def test_no_verification():
    """Test no verification needed case"""
    
    no_verification_input = {
        "verification_needed": False,
        "geographic_region": "IT"
    }
    
    print("=== Testing No Verification Needed ===")
    result = await process_search_request(no_verification_input, None)
    print(f"Status: {result['workflow_status'].value}")
    print(f"Summary: {result.get('intelligent_summary', {})}")
    print()

if __name__ == "__main__":
    asyncio.run(test_basic_search())
    # asyncio.run(test_no_verification())
