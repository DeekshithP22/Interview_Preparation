### agents/search_summarize_agent.py

"""
Standalone Search & Summarize Agent - Multi-source Search & Intelligent Summarization
"""

import logging
from typing import Dict, Any
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import AIMessage
from config import Config
from utils.helpers import safe_json_parse
from utils.state_models import SearchAgentState, SearchWorkflowStatus
from prompts.search_summarize_prompts import (
    TOOL_SELECTION_PROMPT,
    SUMMARIZATION_PROMPT
)

# Configure logging
logger = logging.getLogger(__name__)

# Import your tool implementations
# from tools.italy_trusted_sources import ItalyTrustedSourcesTool
# from tools.france_trusted_sources import FranceTrustedSourcesTool
# from tools.hospital_sources import HospitalSourcesTool
# from tools.linkedin_professional import LinkedInProfessionalTool
# from tools.untrusted_web_search import UntrustedWebSearchTool


class SearchAndSummarizeAgent:
    """
    Standalone Search & Summarize Agent: Multi-source searching + AI summarization
    """
    
    def __init__(self):
        self.llm = AzureChatOpenAI(
            api_key=Config.AZURE_OPENAI_API_KEY,
            azure_endpoint=Config.AZURE_OPENAI_ENDPOINT,
            azure_deployment=Config.AZURE_OPENAI_DEPLOYMENT_NAME,
            api_version=Config.AZURE_OPENAI_API_VERSION,
            temperature=0.1
       )
       
        # Initialize your existing tool instances
        self.search_tools = {
            "italy_trusted": self._initialize_italy_tool(),
            "france_trusted": self._initialize_france_tool(),
            "hospital_sources": self._initialize_hospital_tool(),
            "linkedin_professional": self._initialize_linkedin_tool(),
            "untrusted_web_search": self._initialize_web_tool()
        }
   
    def _initialize_italy_tool(self):
        """Initialize consolidated Italy tool"""
        # TODO: Import your consolidated Italy tool
        # from tools.italy_trusted_sources import ItalyTrustedSourcesTool
        # return ItalyTrustedSourcesTool()
        pass
    
    def _initialize_france_tool(self):
        """Initialize consolidated France tool"""
        # TODO: Import your consolidated France tool
        # from tools.france_trusted_sources import FranceTrustedSourcesTool
        # return FranceTrustedSourcesTool()
        pass
    
    def _initialize_hospital_tool(self):
        """Initialize hospital sources tool"""
        # TODO: Import your hospital tool
        # from tools.hospital_sources import HospitalSourcesTool
        # return HospitalSourcesTool()
        pass
    
    def _initialize_linkedin_tool(self):
        """Initialize LinkedIn professional search tool"""
        # TODO: Import your LinkedIn tool
        # from tools.linkedin_professional import LinkedInProfessionalTool
        # return LinkedInProfessionalTool()
        pass
    
    def _initialize_web_tool(self):
        """Initialize untrusted web search tool"""
        # TODO: Import your web search tool
        # from tools.untrusted_web_search import UntrustedWebSearchTool
        # return UntrustedWebSearchTool()
        pass
    
    async def select_search_tools(self, state: SearchAgentState) -> SearchAgentState:
        """LLM selects appropriate tools based on search input"""
        logger.info("Starting tool selection for search input")
        
        try:
            search_input = state.get("search_input", {})
            
            # Check if search is actually needed
            if not search_input.get("verification_needed", False):
                state.update({
                    "selected_tools": [],
                    "execution_order": [],
                    "search_results": [],
                    "intelligent_summary": {"verification_not_required": True},
                    "search_confidence": 1.0,
                    "workflow_status": SearchWorkflowStatus.SUMMARIZATION_COMPLETED
                })
                
                state["messages"].append(AIMessage(
                    content="No search required based on input"
                ))
                logger.info("No search required - proceeding to completion")
                return state
            
            # Execute tool selection LLM
            logger.info("Executing LLM for tool selection")
            
            selection_response = await self.llm.ainvoke(
                TOOL_SELECTION_PROMPT.format(
                    search_input=search_input
                ).messages
            )
            
            # Parse selection
            tool_selection = safe_json_parse(selection_response.content)
            
            # Update state with tool selection
            state.update({
                "selected_tools": tool_selection.get("selected_tools", []),
                "execution_order": tool_selection.get("execution_order", []),
                "workflow_status": SearchWorkflowStatus.TOOLS_SELECTED
            })
            
            selected_tools_list = tool_selection.get("selected_tools", [])
            
            # LANGSMITH INTEGRATION - Added message for visualization
            state["messages"].append(AIMessage(
                content=f" Selected search tools: {', '.join(selected_tools_list)}"
            ))
            
            logger.info(f"Tools selected successfully: {selected_tools_list}")
            
        except Exception as e:
            logger.error(f"Tool selection error: {str(e)}")
            state.update({
                "workflow_status": SearchWorkflowStatus.ERROR,
                "error_context": {"stage": "tool_selection", "error": str(e)}
            })
            
            state["messages"].append(AIMessage(
                content=f"Tool selection failed: {str(e)}"
            ))
        
        return state
    
    async def execute_search_tools(self, state: SearchAgentState) -> SearchAgentState:
        """Execute selected tools in planned order"""
        logger.info("Starting search tool execution")
        
        try:
            execution_order = state.get("execution_order", [])
            search_input = state.get("search_input", {})
            
            logger.info(f"Executing {len(execution_order)} tools in order")
            
            for tool_name in execution_order:
                logger.debug(f"Executing tool: {tool_name}")
                
                if tool_name in self.search_tools:
                    tool_instance = self.search_tools[tool_name]
                    
                    try:
                        # TODO: Execute tool search
                        # search_result = await tool_instance.search(search_input)
                        # state["search_results"].append(search_result)
                        
                        state["messages"].append(AIMessage(
                            content=f"Executed search with {tool_name}"
                        ))
                        
                        logger.debug(f"Successfully executed {tool_name}")
                        
                    except Exception as tool_error:
                        logger.warning(f"Tool {tool_name} execution failed: {str(tool_error)}")
                        
                        state["messages"].append(AIMessage(
                            content=f"Tool {tool_name} execution failed: {str(tool_error)}"
                        ))
            
            # Update workflow status
            state.update({
                "workflow_status": SearchWorkflowStatus.SEARCH_COMPLETED
            })
            
            # LANGSMITH INTEGRATION - Added message for visualization
            results_count = len(state.get('search_results', []))
            state["messages"].append(AIMessage(
                content=f" Executed {len(execution_order)} search tools, collected {results_count} results"
            ))
            
            logger.info(f"Search tool execution completed")
            
        except Exception as e:
            logger.error(f"Search execution error: {str(e)}")
            state.update({
                "workflow_status": SearchWorkflowStatus.ERROR,
                "error_context": {"stage": "search_execution", "error": str(e)}
            })
            
            state["messages"].append(AIMessage(
                content=f"Search execution failed: {str(e)}"
            ))
        
        return state
    
    async def intelligent_summarization(self, state: SearchAgentState) -> SearchAgentState:
        """LLM creates intelligent summary of all search results"""
        logger.info("Starting intelligent summarization")
        
        try:
            search_results = state.get("search_results", [])
            search_input = state.get("search_input", {})
            vr_data = state.get("vr_data", {})
            
            # Execute summarization LLM
            logger.info("Executing LLM for intelligent summarization")
            
            summary_response = await self.llm.ainvoke(
                SUMMARIZATION_PROMPT.format(
                    search_input=search_input,
                    search_results=search_results,
                    vr_data=vr_data
                ).messages
            )
            
            # Parse summary
            summary_data = safe_json_parse(summary_response.content)
            
            # Extract confidence level
            overall_assessment = summary_data.get("overall_assessment", {})
            confidence_level = overall_assessment.get("confidence_level", 0.0)
            
            # Update state with summary
            state.update({
                "intelligent_summary": summary_data,
                "search_confidence": confidence_level,
                "workflow_status": SearchWorkflowStatus.SUMMARIZATION_COMPLETED
            })
            
            primary_finding = overall_assessment.get("primary_finding", "Summary completed")
            
            # LANGSMITH INTEGRATION - Added message for visualization
            state["messages"].append(AIMessage(
                content=f" Intelligent summary completed. Finding: {primary_finding}, Confidence: {confidence_level:.2f}"
            ))
            
            logger.info(f"Intelligent summarization completed with confidence: {confidence_level}")
            
        except Exception as e:
            logger.error(f"Summarization error: {str(e)}")
            state.update({
                "workflow_status": SearchWorkflowStatus.ERROR,
                "error_context": {"stage": "summarization", "error": str(e)}
            })
            
            state["messages"].append(AIMessage(
                content=f"Summarization failed: {str(e)}"
            ))
        
        return state